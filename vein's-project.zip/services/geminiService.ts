import { GoogleGenAI } from "@google/genai";

// Note: In a real deployment, ensure API_KEY is set in environment variables.
// For this demo, we assume process.env.API_KEY is available.
const apiKey = process.env.API_KEY || ''; 
const ai = new GoogleGenAI({ apiKey });

export const generateCreativeConcept = async (albumTitle: string, baseDescription: string): Promise<string> => {
  if (!apiKey) {
    console.warn("Gemini API Key is missing.");
    return "API Key missing. Unable to generate creative concept.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `You are an avant-garde music critic and creative director. 
      Write a short, poetic, and abstract liner note (max 60 words) for an album titled "${albumTitle}". 
      The base description of the album is: "${baseDescription}".
      Focus on the texture, mood, and visual imagery. Use a sophisticated, editorial tone.`,
    });

    return response.text || "Concept generation failed.";
  } catch (error) {
    console.error("Error generating concept:", error);
    return "Unable to generate concept at this time.";
  }
};