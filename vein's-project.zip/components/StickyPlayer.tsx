import React, { useState, useEffect } from 'react';
import { Track } from '../types';
import { Play, Pause, SkipForward, SkipBack, Volume2 } from 'lucide-react';

interface StickyPlayerProps {
  currentTrack: Track | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext?: () => void;
  onPrev?: () => void;
}

export const StickyPlayer: React.FC<StickyPlayerProps> = ({ currentTrack, isPlaying, onPlayPause, onNext, onPrev }) => {
  const [progress, setProgress] = useState(0);

  // Fake progress simulation
  useEffect(() => {
    let interval: number;
    if (isPlaying) {
      interval = window.setInterval(() => {
        setProgress((prev) => (prev >= 100 ? 0 : prev + 0.5));
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  if (!currentTrack) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 glass-panel px-6 py-5 transition-transform duration-500 ease-out translate-y-0">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Track Info */}
        <div className="flex items-center space-x-5 w-1/3">
          <div className={`relative w-12 h-12 shadow-2xl rounded-sm overflow-hidden border border-white/10 ${isPlaying ? 'animate-[spin_10s_linear_infinite]' : ''}`}>
             <img src={currentTrack.coverUrl} alt="Cover" className="w-full h-full object-cover filter grayscale contrast-125" />
          </div>
          <div className="hidden sm:block">
            <h4 className="text-sm font-bold tracking-tight text-white">{currentTrack.title}</h4>
            <p className="text-xs text-slate-400 font-serif italic tracking-wide">{currentTrack.artist}</p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex flex-col items-center w-1/3">
          <div className="flex items-center space-x-8">
            <button onClick={onPrev} className="text-slate-500 hover:text-white transition-colors">
              <SkipBack size={20} strokeWidth={1.5} />
            </button>
            <button 
              onClick={onPlayPause} 
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white text-black hover:bg-slate-200 transition-colors shadow-[0_0_15px_rgba(255,255,255,0.2)]"
            >
              {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" className="ml-0.5" />}
            </button>
            <button onClick={onNext} className="text-slate-500 hover:text-white transition-colors">
              <SkipForward size={20} strokeWidth={1.5} />
            </button>
          </div>
        </div>

        {/* Volume / Progress (Visual Only) */}
        <div className="hidden md:flex items-center justify-end w-1/3 space-x-4">
          <span className="text-xs font-mono text-slate-500">
            {Math.floor((progress / 100) * 3)}:{Math.floor(((progress / 100) * 180) % 60).toString().padStart(2, '0')}
          </span>
          <div className="w-24 h-0.5 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-white transition-all duration-300 shadow-[0_0_10px_white]" style={{ width: `${progress}%` }}></div>
          </div>
          <Volume2 size={16} className="text-slate-500" />
        </div>

      </div>
    </div>
  );
};